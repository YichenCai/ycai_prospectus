#!/bin/bash
rm -f *~ *.aux *.dvi *.lof *.lot *.toc *.log *.bbl *.blg *.log
