#!/bin/bash
rm -f *~ *.aux *.lof *.lot *.toc *.blg *.log *.bbl *.acr *.acn *.alg *.glg *.glo *.gls *.ist *.out
